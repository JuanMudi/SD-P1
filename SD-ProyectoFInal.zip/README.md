# Start EDGE
python Edge/Actuator/actuator.py
python Edge/QualitySystem/qualitySystem.py

→ For sensors USE Edge\Sensors\CONFIG.md

# Start Fog 

python Fog/MainProxy/mainProxy.py
python Fog/AuxiliarProxy/auxiliarProxy.py
python Fog/QualitySystem/qualitySystem.py

# Start Cloud

python Cloud/Processing/cloudProcessing.py
python Cloud/QualitySystem/qualitySystem.py







